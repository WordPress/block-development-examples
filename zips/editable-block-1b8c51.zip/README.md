# Block Static Rendering b16608

Basic block that shows how to create a block that is editable. This block also show the use of e2e testing for a block.

## Usage

Check the [WordPress Local Development Environment](../../DEVELOPMENT.md#wordpress-local-development-environment) instructions for this repo to see this example in action.

## Install

Check the [Repo Commands > Dependencies](../../DEVELOPMENT.md#dependencies) instructions for this repo
