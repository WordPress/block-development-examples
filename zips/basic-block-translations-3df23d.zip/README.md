# Basic Block Translation 3df23d

Basic block that shows how to use translations in a block.

## Usage

Check the [WordPress Local Development Environment](../../DEVELOPMENT.md#wordpress-local-development-environment) instructions for this repo to see this example in action.

## Install

Check the [Repo Commands > Dependencies](../../DEVELOPMENT.md#dependencies) instructions for this repo
