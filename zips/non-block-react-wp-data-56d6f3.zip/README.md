# Non block React wp-data 56d6f3

This example contains a plugin that extendes the dashboard with a mini React app that shows the use of wp-data

## Usage

Check the [WordPress Local Development Environment](../../DEVELOPMENT.md#wordpress-local-development-environment) instructions for this repo to see this example in action.

## Install

Check the [Repo Commands > Dependencies](../../DEVELOPMENT.md#dependencies) instructions for this repo
