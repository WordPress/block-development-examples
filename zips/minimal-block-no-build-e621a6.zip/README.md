# Minimal Gutenberg Block (No Build)

This example contains a plugin that register a minimal block that has been defined using plain javascript so it doesn't needs a `build` process (to convert the JSX syntax into JS code that browsers can understand).

## Usage

Check the [WordPress Local Development Environment](../../DEVELOPMENT.md#wordpress-local-development-environment) instructions for this repo to see this example in action.

## Install

Check the [Repo Commands > Dependencies](../../DEVELOPMENT.md#dependencies) instructions for this repo
