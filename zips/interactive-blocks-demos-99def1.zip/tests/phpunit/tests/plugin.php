<?php

namespace Gutenberg_Interactive\Tests;

use WP_UnitTestCase;

class Plugin_Test extends WP_UnitTestCase {
	public function test_boostrap() {
	}
}
