# Block Dynamic Rendering 64756b

Basic block that shows how to use of dynamic rendering in a block.

## Usage

Check the [WordPress Local Development Environment](../../DEVELOPMENT.md#wordpress-local-development-environment) instructions for this repo to see this example in action.

## Install

Check the [Repo Commands > Dependencies](../../DEVELOPMENT.md#dependencies) instructions for this repo
